#ifndef Define_H
#define Define_H

#define SwitchOnOff 0

#define RESTRICT_PITCH

#define StepperDin_1 27
#define StepperStp_1 32
#define StepperEn_1 33

#define StepperDin_2 23
#define StepperStp_2 25
#define StepperEn_2 26

#define SPEEDMIN -400000
#define SPEEDMAX 400000

AccelStepper stepper_1(AccelStepper::FULL2WIRE, StepperDin_1, StepperStp_1);
AccelStepper stepper_2(AccelStepper::FULL2WIRE, StepperDin_2, StepperStp_2);


#endif
